# WHR Performance Dashboard

Live-updating Whirlpool Corporation (NYSE: WHR) performance dashboard  
built with Python + Streamlit + yfinance + Plotly.

## What it shows
- **Live price** with day change
- **KPI cards**: Market cap, 52W high/low, P/E, Beta, analyst target
- **Price charts**: 1-year with MA20/MA50, 3-month candlestick, 5-day intraday
- **Financials**: Quarterly revenue & EPS bar chart, EBIT margin trend
- **Segment breakdown**: North America vs Latin America revenue, margin, YoY
- **Full-year 2026 guidance** tracker
- **Analyst price targets**: BofA, Stifel, Mizuho, Citi
- **Risk monitor**: Red/yellow/green flag system
- **Technical indicators**: Bollinger Bands + RSI(14)
- **Peer comparison**: WHR vs HON, MMM, GE, AMETEK
- **Latest news** with auto sentiment tagging
- **Share/ownership stats**

Data cache: **1 hour TTL** — fresh data every time the page loads after an hour.

---

## Deploy to Streamlit Cloud (Free) — Step by Step

### Step 1 — Create a GitHub repo
1. Go to [github.com](https://github.com) → sign in
2. Click **+** → **New repository**
3. Name it `whr-dashboard` → Public → **Create repository**

### Step 2 — Upload files
Upload these two files to the repo root:
- `app.py`
- `requirements.txt`

### Step 3 — Deploy on Streamlit Cloud
1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Sign in with your GitHub account
3. Click **New app**
4. Select your repo: `your-username/whr-dashboard`
5. Branch: `main`
6. Main file: `app.py`
7. Click **Deploy!**

Your dashboard will be live at:  
`https://your-username-whr-dashboard-app-xxxx.streamlit.app`

### Step 4 — Always Fresh Data
- The dashboard caches data for **1 hour** (TTL=3600)
- Every visitor who opens it after the cache expires gets fresh live data
- The page also auto-reloads itself every 60 minutes
- **No cron job needed** — yfinance fetches live data on every uncached load

---

## Local development
```bash
pip install -r requirements.txt
streamlit run app.py
```
Open: http://localhost:8501
